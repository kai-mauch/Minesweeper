#include <SFML/Graphics.hpp>
#include "WelcomeWindow.h"
#include "GameWindow.h"

using namespace std;

int main() {
    // Show welcome window (get player name)
    WelcomeWindow welcome(25, 16);  // Default board size from config

    while (welcome.isOpen()) {
        welcome.handleEvents();
        welcome.render();
    }

    string playerName = welcome.getPlayerName();

    if (playerName.empty()) {
        return 0;  // User closed without entering name
    }

    // Start the game
    GameWindow game(playerName);

    while (game.isOpen()) {
        game.handleEvents();
        game.update();
        game.render();
    }

    return 0;
}